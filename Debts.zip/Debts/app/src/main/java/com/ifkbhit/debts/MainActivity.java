package com.ifkbhit.debts;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import org.androidannotations.annotations.AfterViews;

public class MainActivity extends AppCompatActivity {


    @AfterViews
    void init() {

    }
}
