package com.ifkbhit.debts.recycler;

import android.content.Context;
import android.graphics.Rect;
import android.view.View;

import com.ifkbhit.wallet.StaticUtils;

import org.jetbrains.annotations.NotNull;

import androidx.recyclerview.widget.RecyclerView;

public class DividerDecorator extends RecyclerView.ItemDecoration {


    private Rect offset;


    public DividerDecorator(int dpHeight, Context context) {
        this(new Rect(0, 0, 0, dpHeight), context);
    }

    public DividerDecorator(Rect dps, Context context){
        offset = new Rect(
                StaticUtils.convertDpToPixel(dps.left, context),
                StaticUtils.convertDpToPixel(dps.top, context),
                StaticUtils.convertDpToPixel(dps.right, context),
                StaticUtils.convertDpToPixel(dps.bottom, context)
        );
    }

    @Override
    public void getItemOffsets(@NotNull Rect outRect, @NotNull View view, @NotNull RecyclerView parent,
                               @NotNull RecyclerView.State state) {
        outRect.left = offset.left;
        outRect.right = offset.right;
        outRect.bottom = offset.bottom;
        outRect.top = offset.top;

    }
}
